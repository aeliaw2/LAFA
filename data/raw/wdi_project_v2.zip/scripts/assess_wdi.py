"""Pre-integration quality assessment of the WDI GDP per capita data.
Prints the results and saves them to reports/wdi_quality.txt."""
import pandas as pd

from wdi_common import REPORTS, load_raw


def main():
    rows, aggregates = load_raw()
    lines = []

    def add(text=""):
        lines.append(text)

    total = len(rows)
    rows["is_aggregate"] = rows["iso3"].isna() | rows["iso3"].isin(aggregates)
    countries = rows[~rows["is_aggregate"]].copy()
    values = pd.to_numeric(countries["gdp_per_capita"], errors="coerce")

    add("WDI GDP per capita (current US$) - pre-integration quality assessment")
    add(f"Rows downloaded: {total}")
    add(f"Areas: {rows['iso3'].nunique(dropna=True)} codes "
        f"({countries['iso3'].nunique()} countries, {rows[rows['is_aggregate']]['iso3'].nunique(dropna=True)} regional or income groups)")
    add()

    add("ACCURACY")
    add(f"  Country rows with a number: {values.notna().sum()}")
    if values.notna().any():
        add(f"  Minimum: {values.min():,.2f}  Maximum: {values.max():,.2f}  Median: {values.median():,.2f}")
    add(f"  Zero or negative values: {(values <= 0).sum()}")
    non_numeric = countries["gdp_per_capita"].notna() & values.isna()
    add(f"  Non-numeric values: {non_numeric.sum()}")
    add()

    add("COMPLETENESS")
    missing = values.isna().mean() * 100
    add(f"  Missing values (country rows): {missing:.1f}%")
    per_country = values.groupby(countries["iso3"]).count()
    add(f"  Countries with no values at all: {(per_country == 0).sum()}")
    per_year = values.groupby(countries["year"]).count()
    add(f"  Countries with a value per year: min {per_year.min()}, max {per_year.max()}")
    add()

    add("TIMELINESS")
    years = pd.to_numeric(countries["year"], errors="coerce")
    add(f"  Years covered: {int(years.min())} to {int(years.max())}")
    latest = per_year.sort_index()
    add(f"  Countries with a value in the latest year ({latest.index[-1]}): {latest.iloc[-1]}")
    add()

    add("CONSISTENCY")
    add("  Unit: current US$ (one indicator, NY.GDP.PCAP.CD)")
    four_digit = bool(countries["year"].str.fullmatch(r"\d{4}").all())
    add(f"  Year format all 4 digits: {four_digit}")
    add(f"  Duplicate country-year rows: {countries.duplicated(['iso3', 'year']).sum()}")
    add(f"  Rows with no ISO3 code: {rows['iso3'].isna().sum()}")
    add(f"  Regional or income group rows to remove in cleaning: {rows['is_aggregate'].sum()}")

    report = "\n".join(lines) + "\n"
    print(report)
    REPORTS.mkdir(parents=True, exist_ok=True)
    (REPORTS / "wdi_quality.txt").write_text(report, encoding="utf-8")


if __name__ == "__main__":
    main()
