"""Clean the WDI GDP per capita data.

Issue from the quality assessment -> fix:
  1. Regional and income groups mixed with countries -> removed (World Bank region = "Aggregates").
  2. Rows with no ISO3 code -> removed (cannot be matched to the other datasets).
  3. Years stored as text -> converted to whole numbers.
  4. Missing values -> left blank, not filled in.
Output: data/cleaned/wdi_gdp_per_capita.csv
"""
import pandas as pd

from wdi_common import CLEANED, load_raw


def main():
    rows, aggregates = load_raw()
    start = len(rows)

    no_code = rows["iso3"].isna()
    rows = rows[~no_code]
    is_group = rows["iso3"].isin(aggregates)
    cleaned = rows[~is_group].copy()

    cleaned["year"] = cleaned["year"].astype(int)
    cleaned["gdp_per_capita"] = pd.to_numeric(cleaned["gdp_per_capita"], errors="coerce")
    cleaned = cleaned.sort_values(["iso3", "year"]).reset_index(drop=True)

    CLEANED.mkdir(parents=True, exist_ok=True)
    out = CLEANED / "wdi_gdp_per_capita.csv"
    cleaned.to_csv(out, index=False)

    print(f"Rows in: {start}")
    print(f"Removed, no ISO3 code: {no_code.sum()}")
    print(f"Removed, regional or income groups: {is_group.sum()}")
    print(f"Rows out: {len(cleaned)} ({cleaned['iso3'].nunique()} countries)")
    print(f"Missing values left blank: {cleaned['gdp_per_capita'].isna().sum()}")
    print(f"Saved {out}")


if __name__ == "__main__":
    main()
