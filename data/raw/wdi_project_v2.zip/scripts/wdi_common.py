"""Shared paths and loader for the World Bank WDI scripts."""
import json
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw"
CLEANED = ROOT / "data" / "cleaned"
REPORTS = ROOT / "reports"

INDICATOR_FILE = RAW / "wdi_gdp_per_capita.json"
COUNTRY_FILE = RAW / "wdi_countries.json"


def load_raw():
    """Return (all rows as a DataFrame, set of ISO3 codes that are regional groups)."""
    records = json.loads(INDICATOR_FILE.read_text(encoding="utf-8"))
    countries = json.loads(COUNTRY_FILE.read_text(encoding="utf-8"))

    rows = pd.DataFrame(
        {
            "iso3": [r.get("countryiso3code") or None for r in records],
            "country": [r["country"]["value"] for r in records],
            "year": [r["date"] for r in records],
            "gdp_per_capita": [r["value"] for r in records],
        }
    )
    # World Bank labels every regional group / income group with region "Aggregates"
    aggregates = {c["id"] for c in countries if c["region"]["value"] == "Aggregates"}
    return rows, aggregates
