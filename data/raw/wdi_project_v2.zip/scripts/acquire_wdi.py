"""Download GDP per capita (current US$) from the World Bank WDI API and verify it with SHA-256.

First run: saves the file and its checksum to data/raw/<file>.sha256.
Later runs: download again and stop with an error if the file has changed.
If the World Bank has published a data update and you want to accept it, delete the .sha256 files and rerun.
"""
import hashlib
import json
import sys

import requests

from wdi_common import COUNTRY_FILE, INDICATOR_FILE, RAW

INDICATOR = "NY.GDP.PCAP.CD"  # GDP per capita, current US$
START_YEAR, END_YEAR = 2000, 2025  # matches the FAOSTAT window range
BASE = "https://api.worldbank.org/v2"
HEADERS = {"User-Agent": "data-management-project (UIUC course project)"}


def get_json(url):
    response = requests.get(url, headers=HEADERS, timeout=60)
    response.raise_for_status()
    return response.json()


def fetch_all(url):
    """Follow the API's paging and return every record."""
    records, page = [], 1
    while True:
        meta, data = get_json(f"{url}&page={page}")
        records.extend(data or [])
        if page >= meta["pages"]:
            return records
        page += 1


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save_and_verify(path, records):
    # Sorted keys and fixed formatting make the bytes identical when the data is identical
    text = json.dumps(records, sort_keys=True, ensure_ascii=False, indent=1)
    checksum_file = path.with_name(path.name + ".sha256")
    new_hash = hashlib.sha256(text.encode("utf-8")).hexdigest()

    if checksum_file.exists():
        saved = checksum_file.read_text().split()[0]
        if saved != new_hash:
            sys.exit(f"ERROR: {path.name} changed since the first download.\n"
                     f"  saved checksum: {saved}\n  new checksum:   {new_hash}\n"
                     f"Delete {checksum_file.name} if you want to accept the new data.")
        print(f"{path.name}: checksum matches ({new_hash[:12]}...)")
    else:
        path.write_text(text, encoding="utf-8")
        checksum_file.write_text(f"{new_hash}  {path.name}\n")
        print(f"{path.name}: saved, checksum recorded ({new_hash[:12]}...)")
    if not path.exists():
        path.write_text(text, encoding="utf-8")


def main():
    RAW.mkdir(parents=True, exist_ok=True)
    indicator_url = (f"{BASE}/country/all/indicator/{INDICATOR}"
                     f"?format=json&per_page=20000&date={START_YEAR}:{END_YEAR}")
    country_url = f"{BASE}/country?format=json&per_page=400"

    save_and_verify(INDICATOR_FILE, fetch_all(indicator_url))
    save_and_verify(COUNTRY_FILE, fetch_all(country_url))


if __name__ == "__main__":
    main()
