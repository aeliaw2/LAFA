#!/usr/bin/env bash
# Runs the whole workflow from the project root:  bash run_all.sh
# Stops at the first error. Uses relative paths only.
set -euo pipefail
cd "$(dirname "$0")"

pip install -r requirements.txt

# 1. FAOSTAT undernourishment (Abigail)
python scripts/acquire_faostat.py
python scripts/assess_faostat.py
python scripts/clean_faostat.py

# 2. World Bank WDI GDP per capita (Olusegun)
python scripts/acquire_wdi.py
python scripts/assess_wdi.py
python scripts/clean_wdi.py

# 3. UN SDG maternal mortality (Hamza): add these lines when the scripts are committed
# python scripts/acquire_sdg.py
# python scripts/assess_sdg.py
# python scripts/clean_sdg.py

# 4. Integration and later steps (Shannon, then analysis): add when the scripts exist
# python scripts/integrate.py
# python scripts/assess_integrated.py
# python scripts/analyze.py
